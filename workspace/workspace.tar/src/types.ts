export interface EditingConfig {
  preset: string;
  projectName: string;
  videoType: string;
  pacing: string;
  transitions: string[];
  colorGrading: string;
  audioMixing: boolean;
  backgroundMusic: boolean;
  musicMood: string;
  soundEffects: boolean;
  textOverlays: boolean;
  lowerThirds: boolean;
  introOutro: boolean;
  bRoll: boolean;
  speedRamping: boolean;
  motionGraphics: boolean;
  subtitles: boolean;
  subtitleStyle: string;
  aspectRatio: string;
  resolution: string;
  frameRate: string;
  notes: string;
}

export interface PresetStyle {
  id: string;
  name: string;
  icon: string;
  description: string;
  color: string;
  config: Partial<EditingConfig>;
}
