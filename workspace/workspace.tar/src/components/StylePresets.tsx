import { PresetStyle } from '../types';

const presets: PresetStyle[] = [
  {
    id: 'cinematic',
    name: 'Cinematic',
    icon: '🎬',
    description: 'Film-like quality with dramatic color grading and smooth transitions',
    color: 'from-amber-500 to-orange-600',
    config: {
      pacing: 'slow',
      transitions: ['crossfade', 'dip-to-black'],
      colorGrading: 'cinematic-warm',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'dramatic',
      soundEffects: true,
      textOverlays: false,
      lowerThirds: true,
      introOutro: true,
      bRoll: true,
      speedRamping: true,
      motionGraphics: false,
      subtitles: false,
      subtitleStyle: 'modern',
      aspectRatio: '2.39:1',
      resolution: '4k',
      frameRate: '24',
    },
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: '▶️',
    description: 'Engaging YouTube content with retention-focused editing',
    color: 'from-red-500 to-red-700',
    config: {
      pacing: 'fast',
      transitions: ['whip-pan', 'zoom'],
      colorGrading: 'vibrant',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'uplifting',
      soundEffects: true,
      textOverlays: true,
      lowerThirds: true,
      introOutro: true,
      bRoll: true,
      speedRamping: false,
      motionGraphics: true,
      subtitles: true,
      subtitleStyle: 'bold',
      aspectRatio: '16:9',
      resolution: '4k',
      frameRate: '30',
    },
  },
  {
    id: 'vlog',
    name: 'Vlog',
    icon: '📹',
    description: 'Personal, authentic feel with jump cuts and natural pacing',
    color: 'from-pink-500 to-rose-600',
    config: {
      pacing: 'fast',
      transitions: ['none'],
      colorGrading: 'bright-airty',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'chill',
      soundEffects: true,
      textOverlays: true,
      lowerThirds: false,
      introOutro: true,
      bRoll: true,
      speedRamping: false,
      motionGraphics: false,
      subtitles: true,
      subtitleStyle: 'modern',
      aspectRatio: '16:9',
      resolution: '1080p',
      frameRate: '30',
    },
  },
  {
    id: 'tutorial',
    name: 'Tutorial',
    icon: '📚',
    description: 'Clear educational content with emphasis on clarity and step-by-step flow',
    color: 'from-blue-500 to-indigo-600',
    config: {
      pacing: 'medium',
      transitions: ['crossfade'],
      colorGrading: 'natural',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'chill',
      soundEffects: false,
      textOverlays: true,
      lowerThirds: true,
      introOutro: true,
      bRoll: true,
      speedRamping: false,
      motionGraphics: true,
      subtitles: true,
      subtitleStyle: 'modern',
      aspectRatio: '16:9',
      resolution: '1080p',
      frameRate: '30',
    },
  },
  {
    id: 'gaming',
    name: 'Gaming',
    icon: '🎮',
    description: 'High-energy gaming content with effects, memes, and hype moments',
    color: 'from-green-500 to-emerald-600',
    config: {
      pacing: 'fast',
      transitions: ['glitch', 'zoom', 'whip-pan'],
      colorGrading: 'vibrant',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'energetic',
      soundEffects: true,
      textOverlays: true,
      lowerThirds: false,
      introOutro: true,
      bRoll: false,
      speedRamping: true,
      motionGraphics: true,
      subtitles: true,
      subtitleStyle: 'bold',
      aspectRatio: '16:9',
      resolution: '1080p',
      frameRate: '60',
    },
  },
  {
    id: 'short-form',
    name: 'Short-Form',
    icon: '⚡',
    description: 'TikTok/Reels/Shorts — hook-driven, fast, vertical format',
    color: 'from-violet-500 to-purple-700',
    config: {
      pacing: 'fast',
      transitions: ['zoom', 'whip-pan', 'spin'],
      colorGrading: 'vibrant',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'energetic',
      soundEffects: true,
      textOverlays: true,
      lowerThirds: false,
      introOutro: false,
      bRoll: false,
      speedRamping: true,
      motionGraphics: true,
      subtitles: true,
      subtitleStyle: 'bold',
      aspectRatio: '9:16',
      resolution: '1080p',
      frameRate: '30',
    },
  },
  {
    id: 'documentary',
    name: 'Documentary',
    icon: '🌍',
    description: 'Professional documentary style with interviews and B-roll',
    color: 'from-slate-500 to-gray-700',
    config: {
      pacing: 'medium',
      transitions: ['crossfade', 'dip-to-black'],
      colorGrading: 'cinematic-cool',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'emotional',
      soundEffects: false,
      textOverlays: true,
      lowerThirds: true,
      introOutro: true,
      bRoll: true,
      speedRamping: false,
      motionGraphics: false,
      subtitles: true,
      subtitleStyle: 'modern',
      aspectRatio: '16:9',
      resolution: '4k',
      frameRate: '24',
    },
  },
  {
    id: 'commercial',
    name: 'Commercial',
    icon: '💼',
    description: 'Polished promotional content with brand consistency',
    color: 'from-cyan-500 to-teal-600',
    config: {
      pacing: 'dynamic',
      transitions: ['crossfade', 'dip-to-white', 'zoom'],
      colorGrading: 'high-contrast',
      audioMixing: true,
      backgroundMusic: true,
      musicMood: 'corporate',
      soundEffects: true,
      textOverlays: true,
      lowerThirds: true,
      introOutro: true,
      bRoll: true,
      speedRamping: true,
      motionGraphics: true,
      subtitles: false,
      subtitleStyle: 'modern',
      aspectRatio: '16:9',
      resolution: '4k',
      frameRate: '30',
    },
  },
];

interface Props {
  onSelect: (preset: PresetStyle) => void;
  activePreset: string;
}

export default function StylePresets({ onSelect, activePreset }: Props) {
  return (
    <section>
      <div className="flex items-center gap-2 mb-6">
        <h2 className="text-xl font-semibold text-white">Style Presets</h2>
        <span className="text-sm text-gray-500">— Choose a starting point</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {presets.map((preset) => (
          <button
            key={preset.id}
            onClick={() => onSelect(preset)}
            className={`group relative flex flex-col items-center gap-2 p-4 rounded-xl border transition-all duration-200 ${
              activePreset === preset.id
                ? 'border-purple-500/50 bg-purple-500/10 shadow-lg shadow-purple-500/10'
                : 'border-white/5 bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/10'
            }`}
          >
            <span className="text-2xl">{preset.icon}</span>
            <span className="text-xs font-medium text-gray-300 text-center leading-tight">
              {preset.name}
            </span>
            {activePreset === preset.id && (
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-purple-500 flex items-center justify-center">
                <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
            )}
            <div className={`absolute inset-0 rounded-xl bg-gradient-to-br ${preset.color} opacity-0 group-hover:opacity-5 transition-opacity`} />
          </button>
        ))}
      </div>
    </section>
  );
}
