import { EditingConfig } from '../types';

interface Props {
  config: EditingConfig;
  copied: boolean;
  onCopy: () => void;
}

export default function GeneratedPrompt({ config, copied, onCopy }: Props) {
  const prompt = generatePrompt(config);

  return (
    <div className="sticky top-6">
      <div className="rounded-xl border border-white/5 bg-white/[0.02] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
            <span className="ml-2 text-sm text-gray-400 font-mono">editing-prompt.md</span>
          </div>
          <button
            onClick={onCopy}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              copied
                ? 'bg-green-500/20 text-green-300 border border-green-500/30'
                : 'bg-purple-500/20 text-purple-300 border border-purple-500/30 hover:bg-purple-500/30'
            }`}
          >
            {copied ? (
              <>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                Copied!
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                Copy Prompt
              </>
            )}
          </button>
        </div>

        {/* Content */}
        <div className="max-h-[70vh] overflow-y-auto p-5">
          <pre className="text-xs sm:text-sm text-gray-300 font-mono whitespace-pre-wrap leading-relaxed">
            {prompt}
          </pre>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-white/5 bg-white/[0.01]">
          <p className="text-xs text-gray-500">
            💡 Paste this prompt into Claude along with your video files or editing project to get started.
          </p>
        </div>
      </div>

      {/* How to use */}
      <div className="mt-6 rounded-xl border border-white/5 bg-white/[0.02] p-5">
        <h3 className="text-sm font-semibold text-gray-200 mb-3">🚀 How to Use</h3>
        <ol className="space-y-2 text-sm text-gray-400">
          <li className="flex gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 text-xs flex items-center justify-center font-bold">1</span>
            <span>Configure your editing preferences on the left</span>
          </li>
          <li className="flex gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 text-xs flex items-center justify-center font-bold">2</span>
            <span>Click "Copy Prompt" to copy the generated instructions</span>
          </li>
          <li className="flex gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 text-xs flex items-center justify-center font-bold">3</span>
            <span>Paste into Claude with your video or project files</span>
          </li>
          <li className="flex gap-2">
            <span className="flex-shrink-0 w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 text-xs flex items-center justify-center font-bold">4</span>
            <span>Claude will follow these instructions to edit your video</span>
          </li>
        </ol>
      </div>
    </div>
  );
}

function generatePrompt(config: EditingConfig): string {
  const pacingDescriptions: Record<string, string> = {
    'slow': 'Slow, deliberate pacing with longer takes and breathing room between cuts',
    'medium': 'Moderate pacing with natural rhythm and comfortable cut lengths',
    'fast': 'Fast-paced editing with quick cuts, jump cuts, and energetic rhythm',
    'dynamic': 'Dynamic pacing that varies — slow for emotional moments, fast for action/energy',
  };

  const transitionDescriptions: Record<string, string> = {
    'crossfade': 'Crossfade (smooth dissolve between clips)',
    'dip-to-black': 'Dip to black (fade through black between scenes)',
    'dip-to-white': 'Dip to white (flash transition)',
    'whip-pan': 'Whip pan (fast directional wipe)',
    'zoom': 'Zoom transition (push into/out of next clip)',
    'slide': 'Slide transition (directional push)',
    'glitch': 'Glitch/distortion transition',
    'spin': 'Spin rotation transition',
    'none': 'Hard cuts only (no transitions)',
  };

  const colorDescriptions: Record<string, string> = {
    'cinematic-warm': 'Cinematic warm tones — teal shadows, orange highlights, film-like contrast',
    'cinematic-cool': 'Cinematic cool tones — blue shadows, silver highlights, moody atmosphere',
    'natural': 'Natural/neutral color correction — true-to-life colors with balanced exposure',
    'vintage': 'Vintage/film look — faded blacks, warm shift, grain texture, retro feel',
    'vibrant': 'Vibrant/saturated — punchy colors, high saturation, eye-catching',
    'desaturated': 'Desaturated/muted — low saturation, subtle tones, artistic mood',
    'high-contrast': 'High contrast — deep blacks, bright highlights, dramatic look',
    'bright-airty': 'Bright and airy — lifted shadows, soft highlights, clean look',
  };

  const videoTypeDescriptions: Record<string, string> = {
    'youtube': 'YouTube video (long-form content)',
    'short': 'Short-form video (YouTube Shorts / TikTok / Reels)',
    'tutorial': 'Tutorial/educational content',
    'vlog': 'Vlog/personal content',
    'documentary': 'Documentary-style content',
    'gaming': 'Gaming content',
    'commercial': 'Commercial/promotional content',
    'podcast': 'Podcast/video podcast',
    'wedding': 'Wedding/event video',
    'music-video': 'Music video',
  };

  const musicMoodDescriptions: Record<string, string> = {
    'uplifting': 'Uplifting and positive',
    'dramatic': 'Dramatic and intense',
    'chill': 'Chill and relaxed',
    'energetic': 'High energy and exciting',
    'emotional': 'Emotional and heartfelt',
    'corporate': 'Corporate and professional',
    'dark': 'Dark and mysterious',
  };

  let prompt = `# VIDEO EDITING INSTRUCTIONS
## Project: ${config.projectName}

You are an expert video editor. Follow these detailed instructions to edit this video project.

---

## 📋 PROJECT OVERVIEW
- **Video Type:** ${videoTypeDescriptions[config.videoType] || config.videoType}
- **Aspect Ratio:** ${config.aspectRatio}
- **Resolution:** ${config.resolution}
- **Frame Rate:** ${config.frameRate} fps

---

## 🎬 EDITING STYLE & PACING
${pacingDescriptions[config.pacing] || config.pacing}

**Transitions to use:**
${config.transitions.map((t: string) => `- ${transitionDescriptions[t] || t}`).join('\n')}

---

## 🎨 COLOR GRADING
${colorDescriptions[config.colorGrading] || config.colorGrading}

Apply consistent color grading across all clips. Ensure skin tones remain natural. Match exposure levels between different camera angles/sources.

---

## 🎵 AUDIO
${config.audioMixing ? '✅ **Audio Mixing:** Balance all audio levels. Dialogue should be the priority (-12dB to -6dB). Reduce background noise. Normalize levels across clips.' : '❌ No audio mixing required.'}
${config.backgroundMusic ? `✅ **Background Music:** Use ${musicMoodDescriptions[config.musicMood] || config.musicMood} music. Duck music under dialogue (reduce by -15dB to -20dB when someone is speaking). Fade music in at start and out at end.` : '❌ No background music.'}
${config.soundEffects ? '✅ **Sound Effects:** Add subtle sound effects for transitions, text appearances, and emphasis moments. Use whooshes, impacts, and UI sounds sparingly.' : '❌ No sound effects.'}

---

## ✨ VISUAL ELEMENTS
${config.textOverlays ? '✅ **Text Overlays:** Add text overlays for key points, chapter titles, and emphasis. Use clean, modern typography.' : '❌ No text overlays.'}
${config.lowerThirds ? '✅ **Lower Thirds:** Add lower third graphics for speaker names/titles. Use consistent styling throughout.' : '❌ No lower thirds.'}
${config.introOutro ? '✅ **Intro/Outro:** Create a brief intro (3-5 seconds) and outro (5-10 seconds) with branding elements.' : '❌ No intro/outro.'}
${config.bRoll ? '✅ **B-Roll:** Cut to B-roll footage to maintain visual interest. Use B-roll to cover cuts and add context.' : '❌ No B-roll.'}
${config.speedRamping ? '✅ **Speed Ramping:** Use speed ramps for dramatic effect — slow down key moments, speed up transitions.' : '❌ No speed ramping.'}
${config.motionGraphics ? '✅ **Motion Graphics:** Add animated graphics, data visualizations, or animated elements where appropriate.' : '❌ No motion graphics.'}

---

## 📝 SUBTITLES & CAPTIONS
${config.subtitles ? `✅ **Subtitles:** Add subtitles/captions throughout. Style: ${config.subtitleStyle}. Ensure readability with proper contrast against background.` : '❌ No subtitles.'}

---

## 📐 TECHNICAL SPECS
| Setting | Value |
|---------|-------|
| Aspect Ratio | ${config.aspectRatio} |
| Resolution | ${config.resolution} |
| Frame Rate | ${config.frameRate} fps |
| Export Format | H.264/H.265 MP4 |
| Bitrate | High (match source quality) |

---

## 📝 EDITOR'S NOTES
${config.notes || 'No additional notes provided.'}

---

## ✅ EDITING CHECKLIST
- [ ] Rough cut assembled in story order
- [ ] All dead air, mistakes, and filler removed
- [ ] Pacing matches the specified style
- [ ] Transitions applied as specified
- [ ] Color grading applied consistently
- [ ] Audio levels balanced and normalized
- [ ] Background music added and ducked properly
- [ ] Text overlays and lower thirds added
- [ ] Subtitles/captions added and synced
- [ ] Intro and outro added
- [ ] Final review for continuity errors
- [ ] Export at specified resolution and format`;

  return prompt;
}
