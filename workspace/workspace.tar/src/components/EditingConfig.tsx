import type { EditingConfig as EditingConfigType } from '../types';

interface Props {
  config: EditingConfigType;
  onChange: (key: keyof EditingConfigType, value: any) => void;
}

const transitionOptions = [
  { id: 'crossfade', label: 'Crossfade', icon: '🔀' },
  { id: 'dip-to-black', label: 'Dip to Black', icon: '⬛' },
  { id: 'dip-to-white', label: 'Dip to White', icon: '⬜' },
  { id: 'whip-pan', label: 'Whip Pan', icon: '💨' },
  { id: 'zoom', label: 'Zoom', icon: '🔍' },
  { id: 'slide', label: 'Slide', icon: '➡️' },
  { id: 'glitch', label: 'Glitch', icon: '⚡' },
  { id: 'spin', label: 'Spin', icon: '🔄' },
  { id: 'none', label: 'Hard Cuts', icon: '✂️' },
];

export default function EditingConfigPanel({ config, onChange }: Props) {
  const toggleTransition = (id: string) => {
    if (id === 'none') {
      onChange('transitions', ['none']);
      return;
    }
    const current = config.transitions.filter(t => t !== 'none');
    if (current.includes(id)) {
      onChange('transitions', current.filter(t => t !== id));
    } else {
      onChange('transitions', [...current, id]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Project Details */}
      <ConfigSection title="📋 Project Details" icon="">
        <div className="space-y-4">
          <InputField
            label="Project Name"
            value={config.projectName}
            onChange={(v) => onChange('projectName', v)}
            placeholder="My Video Project"
          />
          <SelectField
            label="Video Type"
            value={config.videoType}
            onChange={(v) => onChange('videoType', v)}
            options={[
              { value: 'youtube', label: 'YouTube (Long-form)' },
              { value: 'short', label: 'Short-form (TikTok/Reels/Shorts)' },
              { value: 'tutorial', label: 'Tutorial / Educational' },
              { value: 'vlog', label: 'Vlog / Personal' },
              { value: 'documentary', label: 'Documentary' },
              { value: 'gaming', label: 'Gaming' },
              { value: 'commercial', label: 'Commercial / Promo' },
              { value: 'podcast', label: 'Podcast / Video Podcast' },
              { value: 'wedding', label: 'Wedding / Event' },
              { value: 'music-video', label: 'Music Video' },
            ]}
          />
        </div>
      </ConfigSection>

      {/* Pacing & Transitions */}
      <ConfigSection title="🎬 Pacing & Transitions" icon="">
        <div className="space-y-4">
          <SelectField
            label="Pacing Style"
            value={config.pacing}
            onChange={(v) => onChange('pacing', v)}
            options={[
              { value: 'slow', label: '🐢 Slow & Deliberate' },
              { value: 'medium', label: '🚶 Moderate & Natural' },
              { value: 'fast', label: '🏃 Fast & Energetic' },
              { value: 'dynamic', label: '🎭 Dynamic (varies by scene)' },
            ]}
          />
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Transitions</label>
            <div className="flex flex-wrap gap-2">
              {transitionOptions.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => toggleTransition(opt.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    config.transitions.includes(opt.id)
                      ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                      : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  {opt.icon} {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </ConfigSection>

      {/* Color Grading */}
      <ConfigSection title="🎨 Color Grading" icon="">
        <SelectField
          label="Color Grade"
          value={config.colorGrading}
          onChange={(v) => onChange('colorGrading', v)}
          options={[
            { value: 'cinematic-warm', label: '🟠 Cinematic Warm (teal & orange)' },
            { value: 'cinematic-cool', label: '🔵 Cinematic Cool (blue & silver)' },
            { value: 'natural', label: '🟢 Natural / True-to-life' },
            { value: 'vintage', label: '📷 Vintage / Film Look' },
            { value: 'vibrant', label: '🌈 Vibrant / Saturated' },
            { value: 'desaturated', label: '🩶 Desaturated / Muted' },
            { value: 'high-contrast', label: '⚫ High Contrast / Dramatic' },
            { value: 'bright-airty', label: '☀️ Bright & Airy' },
          ]}
        />
      </ConfigSection>

      {/* Audio */}
      <ConfigSection title="🎵 Audio" icon="">
        <div className="space-y-4">
          <ToggleField
            label="Audio Mixing"
            description="Balance levels, reduce noise, normalize"
            checked={config.audioMixing}
            onChange={(v) => onChange('audioMixing', v)}
          />
          <ToggleField
            label="Background Music"
            description="Add music that fits the mood"
            checked={config.backgroundMusic}
            onChange={(v) => onChange('backgroundMusic', v)}
          />
          {config.backgroundMusic && (
            <SelectField
              label="Music Mood"
              value={config.musicMood}
              onChange={(v) => onChange('musicMood', v)}
              options={[
                { value: 'uplifting', label: '😊 Uplifting & Positive' },
                { value: 'dramatic', label: '🎭 Dramatic & Intense' },
                { value: 'chill', label: '😌 Chill & Relaxed' },
                { value: 'energetic', label: '🔥 High Energy' },
                { value: 'emotional', label: '💫 Emotional & Heartfelt' },
                { value: 'corporate', label: '💼 Corporate & Professional' },
                { value: 'dark', label: '🌑 Dark & Mysterious' },
              ]}
            />
          )}
          <ToggleField
            label="Sound Effects"
            description="Whooshes, impacts, UI sounds"
            checked={config.soundEffects}
            onChange={(v) => onChange('soundEffects', v)}
          />
        </div>
      </ConfigSection>

      {/* Visual Elements */}
      <ConfigSection title="✨ Visual Elements" icon="">
        <div className="space-y-3">
          <ToggleField label="Text Overlays" description="Key points, titles, emphasis" checked={config.textOverlays} onChange={(v) => onChange('textOverlays', v)} />
          <ToggleField label="Lower Thirds" description="Speaker names and titles" checked={config.lowerThirds} onChange={(v) => onChange('lowerThirds', v)} />
          <ToggleField label="Intro / Outro" description="Branded intro and outro sequences" checked={config.introOutro} onChange={(v) => onChange('introOutro', v)} />
          <ToggleField label="B-Roll" description="Cutaway footage for visual interest" checked={config.bRoll} onChange={(v) => onChange('bRoll', v)} />
          <ToggleField label="Speed Ramping" description="Slow-mo and speed-up effects" checked={config.speedRamping} onChange={(v) => onChange('speedRamping', v)} />
          <ToggleField label="Motion Graphics" description="Animated graphics and data viz" checked={config.motionGraphics} onChange={(v) => onChange('motionGraphics', v)} />
        </div>
      </ConfigSection>

      {/* Subtitles */}
      <ConfigSection title="📝 Subtitles & Captions" icon="">
        <div className="space-y-4">
          <ToggleField
            label="Subtitles"
            description="Add captions throughout the video"
            checked={config.subtitles}
            onChange={(v) => onChange('subtitles', v)}
          />
          {config.subtitles && (
            <SelectField
              label="Subtitle Style"
              value={config.subtitleStyle}
              onChange={(v) => onChange('subtitleStyle', v)}
              options={[
                { value: 'modern', label: 'Modern (clean, minimal)' },
                { value: 'bold', label: 'Bold (large, attention-grabbing)' },
                { value: 'karaoke', label: 'Karaoke (word-by-word highlight)' },
                { value: 'classic', label: 'Classic (traditional subtitles)' },
              ]}
            />
          )}
        </div>
      </ConfigSection>

      {/* Technical Specs */}
      <ConfigSection title="📐 Technical Specs" icon="">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <SelectField
            label="Aspect Ratio"
            value={config.aspectRatio}
            onChange={(v) => onChange('aspectRatio', v)}
            options={[
              { value: '16:9', label: '16:9 (Widescreen)' },
              { value: '9:16', label: '9:16 (Vertical)' },
              { value: '1:1', label: '1:1 (Square)' },
              { value: '4:5', label: '4:5 (Instagram)' },
              { value: '2.39:1', label: '2.39:1 (Cinematic)' },
              { value: '4:3', label: '4:3 (Classic)' },
            ]}
          />
          <SelectField
            label="Resolution"
            value={config.resolution}
            onChange={(v) => onChange('resolution', v)}
            options={[
              { value: '4k', label: '4K (2160p)' },
              { value: '1080p', label: '1080p (Full HD)' },
              { value: '720p', label: '720p (HD)' },
            ]}
          />
          <SelectField
            label="Frame Rate"
            value={config.frameRate}
            onChange={(v) => onChange('frameRate', v)}
            options={[
              { value: '24', label: '24 fps (Cinematic)' },
              { value: '30', label: '30 fps (Standard)' },
              { value: '60', label: '60 fps (Smooth)' },
            ]}
          />
        </div>
      </ConfigSection>

      {/* Notes */}
      <ConfigSection title="📝 Additional Notes" icon="">
        <textarea
          value={config.notes}
          onChange={(e) => onChange('notes', e.target.value)}
          placeholder="Any specific instructions, references, or notes for the editor..."
          className="w-full h-28 px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/25 resize-none transition-all"
        />
      </ConfigSection>
    </div>
  );
}

function ConfigSection({ title, children }: { title: string; icon: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-white/5 bg-white/[0.02] p-5">
      <h3 className="text-sm font-semibold text-gray-200 mb-4">{title}</h3>
      {children}
    </div>
  );
}

function InputField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-300 mb-1.5">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/25 transition-all"
      />
    </div>
  );
}

function SelectField({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-300 mb-1.5">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/25 transition-all appearance-none cursor-pointer"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-gray-900">
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}

function ToggleField({ label, description, checked, onChange }: { label: string; description: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between py-1">
      <div>
        <span className="text-sm font-medium text-gray-200">{label}</span>
        <p className="text-xs text-gray-500">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors ${
          checked ? 'bg-purple-500' : 'bg-white/10'
        }`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
            checked ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
}
