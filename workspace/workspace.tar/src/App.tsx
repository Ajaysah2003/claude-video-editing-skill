import { useState } from 'react';
import Header from './components/Header';
import StylePresets from './components/StylePresets';
import EditingConfigPanel from './components/EditingConfig';
import GeneratedPrompt from './components/GeneratedPrompt';
import { EditingConfig as EditingConfigType, PresetStyle } from './types';

const defaultConfig: EditingConfigType = {
  preset: 'cinematic',
  projectName: 'My Video Project',
  videoType: 'youtube',
  pacing: 'medium',
  transitions: ['crossfade', 'dip-to-black'],
  colorGrading: 'cinematic-warm',
  audioMixing: true,
  backgroundMusic: true,
  musicMood: 'uplifting',
  soundEffects: true,
  textOverlays: true,
  lowerThirds: true,
  introOutro: true,
  bRoll: true,
  speedRamping: false,
  motionGraphics: false,
  subtitles: true,
  subtitleStyle: 'modern',
  aspectRatio: '16:9',
  resolution: '4k',
  frameRate: '24',
  notes: '',
};

export default function App() {
  const [config, setConfig] = useState<EditingConfigType>(defaultConfig);
  const [copied, setCopied] = useState(false);

  const handlePresetSelect = (preset: PresetStyle) => {
    setConfig(prev => ({
      ...prev,
      ...preset.config,
      preset: preset.id,
    }));
  };

  const handleConfigChange = (key: keyof EditingConfigType, value: any) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  };

  const handleCopy = () => {
    const prompt = generatePrompt(config);
    navigator.clipboard.writeText(prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <StylePresets onSelect={handlePresetSelect} activePreset={config.preset} />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-10">
          <EditingConfigPanel config={config} onChange={handleConfigChange} />
          <GeneratedPrompt config={config} copied={copied} onCopy={handleCopy} />
        </div>
      </main>
    </div>
  );
}

function generatePrompt(config: EditingConfigType): string {
  const pacingDescriptions: Record<string, string> = {
    'slow': 'Slow, deliberate pacing with longer takes and breathing room between cuts',
    'medium': 'Moderate pacing with natural rhythm and comfortable cut lengths',
    'fast': 'Fast-paced editing with quick cuts, jump cuts, and energetic rhythm',
    'dynamic': 'Dynamic pacing that varies — slow for emotional moments, fast for action/energy',
  };

  const transitionDescriptions: Record<string, string> = {
    'crossfade': 'Crossfade (smooth dissolve between clips)',
    'dip-to-black': 'Dip to black (fade through black between scenes)',
    'dip-to-white': 'Dip to white (flash transition)',
    'whip-pan': 'Whip pan (fast directional wipe)',
    'zoom': 'Zoom transition (push into/out of next clip)',
    'slide': 'Slide transition (directional push)',
    'glitch': 'Glitch/distortion transition',
    'spin': 'Spin rotation transition',
    'none': 'Hard cuts only (no transitions)',
  };

  const colorDescriptions: Record<string, string> = {
    'cinematic-warm': 'Cinematic warm tones — teal shadows, orange highlights, film-like contrast',
    'cinematic-cool': 'Cinematic cool tones — blue shadows, silver highlights, moody atmosphere',
    'natural': 'Natural/neutral color correction — true-to-life colors with balanced exposure',
    'vintage': 'Vintage/film look — faded blacks, warm shift, grain texture, retro feel',
    'vibrant': 'Vibrant/saturated — punchy colors, high saturation, eye-catching',
    'desaturated': 'Desaturated/muted — low saturation, subtle tones, artistic mood',
    'high-contrast': 'High contrast — deep blacks, bright highlights, dramatic look',
    'bright-airty': 'Bright and airy — lifted shadows, soft highlights, clean look',
  };

  const videoTypeDescriptions: Record<string, string> = {
    'youtube': 'YouTube video (long-form content)',
    'short': 'Short-form video (YouTube Shorts / TikTok / Reels)',
    'tutorial': 'Tutorial/educational content',
    'vlog': 'Vlog/personal content',
    'documentary': 'Documentary-style content',
    'gaming': 'Gaming content',
    'commercial': 'Commercial/promotional content',
    'podcast': 'Podcast/video podcast',
    'wedding': 'Wedding/event video',
    'music-video': 'Music video',
  };

  const musicMoodDescriptions: Record<string, string> = {
    'uplifting': 'Uplifting and positive',
    'dramatic': 'Dramatic and intense',
    'chill': 'Chill and relaxed',
    'energetic': 'High energy and exciting',
    'emotional': 'Emotional and heartfelt',
    'corporate': 'Corporate and professional',
    'dark': 'Dark and mysterious',
    'none': 'No background music',
  };

  let prompt = `# VIDEO EDITING INSTRUCTIONS
## Project: ${config.projectName}

You are an expert video editor. Follow these detailed instructions to edit this video project.

---

## 📋 PROJECT OVERVIEW
- **Video Type:** ${videoTypeDescriptions[config.videoType] || config.videoType}
- **Aspect Ratio:** ${config.aspectRatio}
- **Resolution:** ${config.resolution}
- **Frame Rate:** ${config.frameRate} fps

---

## 🎬 EDITING STYLE & PACING
${pacingDescriptions[config.pacing] || config.pacing}

**Transitions to use:**
${config.transitions.map(t => `- ${transitionDescriptions[t] || t}`).join('\n')}

---

## 🎨 COLOR GRADING
${colorDescriptions[config.colorGrading] || config.colorGrading}

Apply consistent color grading across all clips. Ensure skin tones remain natural. Match exposure levels between different camera angles/sources.

---

## 🎵 AUDIO
${config.audioMixing ? '✅ **Audio Mixing:** Balance all audio levels. Dialogue should be the priority (-12dB to -6dB). Reduce background noise. Normalize levels across clips.' : '❌ No audio mixing required.'}
${config.backgroundMusic ? `✅ **Background Music:** Use ${musicMoodDescriptions[config.musicMood] || config.musicMood} music. Duck music under dialogue (reduce by -15dB to -20dB when someone is speaking). Fade music in at start and out at end.` : '❌ No background music.'}
${config.soundEffects ? '✅ **Sound Effects:** Add subtle sound effects for transitions, text appearances, and emphasis moments. Use whooshes, impacts, and UI sounds sparingly.' : '❌ No sound effects.'}

---

## ✨ VISUAL ELEMENTS
${config.textOverlays ? '✅ **Text Overlays:** Add text overlays for key points, chapter titles, and emphasis. Use clean, modern typography.' : '❌ No text overlays.'}
${config.lowerThirds ? '✅ **Lower Thirds:** Add lower third graphics for speaker names/titles. Use consistent styling throughout.' : '❌ No lower thirds.'}
${config.introOutro ? '✅ **Intro/Outro:** Create a brief intro (3-5 seconds) and outro (5-10 seconds) with branding elements.' : '❌ No intro/outro.'}
${config.bRoll ? '✅ **B-Roll:** Cut to B-roll footage to maintain visual interest. Use B-roll to cover cuts and add context.' : '❌ No B-roll.'}
${config.speedRamping ? '✅ **Speed Ramping:** Use speed ramps for dramatic effect — slow down key moments, speed up transitions.' : '❌ No speed ramping.'}
${config.motionGraphics ? '✅ **Motion Graphics:** Add animated graphics, data visualizations, or animated elements where appropriate.' : '❌ No motion graphics.'}

---

## 📝 SUBTITLES & CAPTIONS
${config.subtitles ? `✅ **Subtitles:** Add subtitles/captions throughout. Style: ${config.subtitleStyle}. Ensure readability with proper contrast against background.` : '❌ No subtitles.'}

---

## 📐 TECHNICAL SPECS
| Setting | Value |
|---------|-------|
| Aspect Ratio | ${config.aspectRatio} |
| Resolution | ${config.resolution} |
| Frame Rate | ${config.frameRate} fps |
| Export Format | H.264/H.265 MP4 |
| Bitrate | High (match source quality) |

---

## 📝 EDITOR'S NOTES
${config.notes || 'No additional notes provided.'}

---

## ✅ EDITING CHECKLIST
- [ ] Rough cut assembled in story order
- [ ] All dead air, mistakes, and filler removed
- [ ] Pacing matches the specified style
- [ ] Transitions applied as specified
- [ ] Color grading applied consistently
- [ ] Audio levels balanced and normalized
- [ ] Background music added and ducked properly
- [ ] Text overlays and lower thirds added
- [ ] Subtitles/captions added and synced
- [ ] Intro and outro added
- [ ] Final review for continuity errors
- [ ] Export at specified resolution and format
`;

  return prompt;
}
