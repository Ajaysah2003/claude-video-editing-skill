# 🎬 Claude Video Editing Skill Generator

Configure your video editing style and generate comprehensive prompts for Claude AI to edit your videos exactly how you want.

![React](https://img.shields.io/badge/React-18-blue?logo=react)
![Vite](https://img.shields.io/badge/Vite-6-purple?logo=vite)
![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-4-cyan?logo=tailwindcss)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)

## ✨ Features

- 🎬 **8 Style Presets** — Cinematic, YouTube, Vlog, Tutorial, Gaming, Short-Form, Documentary, Commercial
- 🎨 **Color Grading Options** — 8 different color grading styles
- 🎵 **Audio Configuration** — Music mood, sound effects, audio mixing
- ✨ **Visual Elements** — Text overlays, lower thirds, B-roll, speed ramping, motion graphics
- 📝 **Subtitles** — Multiple subtitle styles
- 📐 **Technical Specs** — Aspect ratio, resolution, frame rate
- 📋 **One-Click Copy** — Generate and copy the complete editing prompt instantly

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v18 or higher)
- [npm](https://www.npmjs.com/) or [yarn](https://yarnpkg.com/)

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/claude-video-editing-skill.git
cd claude-video-editing-skill

# Install dependencies
npm install

# Start development server
npm run dev
```

### Build for Production

```bash
npm run build
```

The built files will be in the `dist/` directory.

## 📖 How to Use

1. **Choose a Style Preset** — Pick from Cinematic, YouTube, Vlog, Gaming, etc.
2. **Customize Settings** — Adjust pacing, transitions, color grading, audio, and more
3. **Add Notes** — Include any specific instructions for your project
4. **Copy the Prompt** — Click "Copy Prompt" to copy the generated instructions
5. **Paste into Claude** — Open Claude AI and paste the prompt along with your video files

## 🛠️ Tech Stack

- **React 18** — UI framework
- **Vite** — Build tool
- **TypeScript** — Type safety
- **Tailwind CSS** — Styling

## 📄 License

MIT License — feel free to use this project for personal or commercial purposes.

## 🤝 Contributing

Contributions are welcome! Feel free to open issues or submit pull requests.

---

Made with ❤️ for video creators
